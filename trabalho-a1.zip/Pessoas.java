public abstract class Pessoas {
    
    String nome;
    
    public Pessoas(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
    
}