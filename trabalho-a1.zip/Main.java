public class Main
{
	public static void main(String[] args) {
	    Ensalamento.execEnsalamento();
	    Ensalamento.imprimirTurmasEAlunos();
	}
}
