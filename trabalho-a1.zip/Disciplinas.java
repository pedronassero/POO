public class Disciplinas {
    
    public String nome;
    
    public Disciplinas(String nome) {
        this.nome = nome;
    }
    
    public String getNome() {
        return nome;
    }
    
}